<?php
// 创建文件 test_zip.php
echo "PHP版本: " . phpversion() . "\n";
echo "fileinfo扩展: " . (extension_loaded('fileinfo') ? '已启用' : '未启用') . "\n";

if (function_exists('finfo_open')) {
    $testFile = 'path/to/your/zip/file.zip'; // 替换为实际ZIP文件路径
    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    echo "ZIP文件MIME类型检测结果: " . finfo_file($finfo, $testFile) . "\n";
    finfo_close($finfo);
}

echo "上传限制:\n";
echo "upload_max_filesize: " . ini_get('upload_max_filesize') . "\n";
echo "post_max_size: " . ini_get('post_max_size') . "\n";
echo "max_file_uploads: " . ini_get('max_file_uploads') . "\n";
?>
